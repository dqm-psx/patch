DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.46 beta - public playtest
Latest package: DQM1-2-English-v1.0.46-beta-public.zip

Unofficial fan English translation of
ドラゴンクエストモンスターズ1・2 星降りの勇者と牧場の仲間たち
(Dragon Quest Monsters 1 & 2: The Starry Night Hero and Friends at the Ranch).

English text and title artwork for Terry's, Cobi's and Tara's adventures.

PUBLIC RELEASE HIGHLIGHTS
v46: Makes the original Japanese game's hidden movement mode accessible
     with the hero name Sanic (capital S). Hold Square while changing
     areas to activate faster movement. The original behavior and
     the みんさん trigger for existing saves are preserved.
v45: Clear item-description headers without the repeated "Items" label:
     Single use (consumed), Reusable (may break), Unlimited uses,
     Key item, or Accessory, as appropriate to the item.
     Built directly from v43, retaining its inventory fixes: using or
     discarding one copy keeps the remaining stack in place, and a
     rejected battle item returns the cursor to its correct row.
     Item effects, consumption rules, fonts and dialogue spacing remain
     v43. This build does not include v44's font changes.
v38: Fixed the Master Teto breeding crash and NPC breeding names
     overwriting monster data.
v36: Fixed DQM2 gate room text glitches and improved key names.
v34: Fixed the original Japanese Truth gate / Digster progression bug
     and intermittent portal-entry crashes.
v30: Improved inventory, status bars and dialogue; fixed the
     Arena/School transition bug.
v23: English text and title artwork, menu fixes and expanded HP/MP displays.

REQUIRED GAME
Unmodified Japanese PlayStation BIN, serial SLPM-87050.
Size: 260,975,568 bytes
Source SHA-256:
a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29

INSTALL
1. Extract the latest package. Apply its .bps to the original Japanese
   BIN using a BPS patcher, such as:
   https://www.marcrobledo.com/RomPatcher.js/
   Do not patch an already translated image. Keep checksum validation on.
2. Name the output DQM1-2-English-v1.0.46-beta.bin and place it beside the
   included DQM1-2-English-v1.0.46-beta.cue.
3. Open that CUE in your PlayStation emulator. Boot fresh, then load your
   existing in-game memory-card save to continue playing after updating.
4. Avoid emulator save states from other patch versions.

Patched BIN SHA-256:
73d901c05aecce712ccc45899fa28604c4815a458e7d61a5a3b78e4c80ecee73

PLAYTESTING
Back up your saves. v46 passed static code, data and full-disc checks;
the BPS patch and supplied development installer reproduce the same BIN.
No emulator or game-instruction testing was performed for v46.
Full campaign playthroughs and original-hardware compatibility remain
unverified. Some names are shortened, and some area transitions may load
more slowly than in the Japanese game.
For bugs, report the version, campaign, location and steps to reproduce;
include a screenshot and, if possible, a save from before the issue.

Game and BIOS files are not included. Earlier public packages are retained.
