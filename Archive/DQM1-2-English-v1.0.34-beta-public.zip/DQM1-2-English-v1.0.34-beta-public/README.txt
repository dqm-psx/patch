DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.34 beta - public playtest
Package: DQM1-2-English-v1.0.34-beta-public.zip

English text and title artwork for Terry's, Cobi's and Tara's adventures.
v34 includes the original Truth gate / Digster progression repair and fixes
intermittent Truth gate entry crashes in the English build. Earlier inventory, status bar,
dialogue and Arena/School improvements are included.

REQUIRED GAME
Unmodified Japanese PlayStation BIN, serial SLPM-87050.
Size: 260,975,568 bytes
Source SHA-256:
a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29

INSTALL
1. Extract the package. Use a BPS patcher to apply the included .bps to the
   original Japanese BIN. Do not patch an already translated image. Keep
   checksum validation enabled.
2. Name the output DQM1-2-English-v1.0.34-beta.bin and place it beside the
   included DQM1-2-English-v1.0.34-beta.cue.
3. Open that CUE in your PlayStation emulator. Boot fresh and load an in-game
   memory-card save; do not resume a save state from another patch version.

Patched BIN SHA-256:
ad22e5c22ffc88da6cc4d72a7b9162fcbc763f265cbdc4d6981418dc361fd5ea

PLAYTESTING
Back up your saves. Full campaign playthroughs and original-hardware
compatibility are unverified. Some names are shortened. Some area transitions
may load more slowly than in the Japanese game.
For bugs, report the version, campaign, location and steps to reproduce;
include a screenshot and, if possible, a save from before the issue.

Unofficial fan translation. Game and BIOS files are not included.
