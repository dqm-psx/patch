DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.45 beta - concise item information headers

Built directly from v1.0.43 beta. Item descriptions now show a concise
status header selected from the item's own attributes:

  Single use (consumed)
  Reusable (may break)
  Unlimited uses
  Key item
  Accessory

The detail header no longer repeats the word "Items". Wider panels use
one status line; narrower panels use their existing separate rows.
"Reusable (may break)" describes a breakable item without implying a
fixed number of remaining uses. Item effects and consumption rules are
unchanged.

Includes v43's inventory stack-order fix and battle rejection cursor
correction. The v43 fonts, dialogue spacing, item descriptions and other
translated wording are preserved. This build does not include v44's
font changes.

INSTALLATION
Apply DQM1-2-English-v1.0.45-beta.bps to your unmodified Japanese game BIN using a
BPS-compatible patcher. Keep the supplied CUE beside the resulting BIN
and open the CUE in your PlayStation emulator.

Required source: Dragon Quest Monsters 1 & 2 - Hoshifuri no Yuusha to Bokujou no Nakama-tachi (Japan).bin
Source SHA-256: a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29
Output SHA-256: 472f85ffeae97f8ef62852f0a5d755c14fbcd4176451b3912a0a79d845c01418

Load an in-game memory-card save when changing versions. Avoid loading
a save state from an older build, which can restore that build's old code.

VERIFICATION
Static source/data tests and an independent comparison of the complete
disc check item classification, header encoding and layout bounds, and
preservation of v43 content outside the bounded header changes.
Sector checksums, BPS application and the supplied development-package
installer are verified. No emulator or game-instruction tests were run
for v45. Gameplay, full playthrough and physical-console testing are
not claimed. Detailed evidence is included in the development package.

This is an unofficial fan translation. Game and BIOS files are not included.
