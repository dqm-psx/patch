DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.38 beta - public playtest
Package: DQM1-2-English-v1.0.38-beta-public.zip

Unofficial fan English translation of
ドラゴンクエストモンスターズ1・2 星降りの勇者と牧場の仲間たち
(Dragon Quest Monsters 1 & 2: The Starry Night Hero and Friends at the Ranch).

English text and title artwork for Terry's, Cobi's and Tara's adventures.

PUBLIC RELEASE HIGHLIGHTS
v38:
- Fixed the crash when Master Teto offers to breed a monster.
- Fixed NPC breeding names overwriting monster data.
v36: Fixed DQM2 gate room text glitches and improved key names.
v34: Fixed the original Japanese Truth gate / Digster progression bug
     and intermittent portal-entry crashes.
v30: Improved inventory, status bars and dialogue; fixed the
     Arena/School transition bug.
v23: English text and title artwork, menu fixes and expanded HP/MP displays.

REQUIRED GAME
Unmodified Japanese PlayStation BIN, serial SLPM-87050.
Size: 260,975,568 bytes
Source SHA-256:
a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29

INSTALL
1. Extract the package. Apply the included .bps to the original Japanese
   BIN using a BPS patcher, such as:
   https://www.marcrobledo.com/RomPatcher.js/
   Do not patch an already translated image. Keep checksum validation on.
2. Name the output DQM1-2-English-v1.0.38-beta.bin and place it beside the
   included DQM1-2-English-v1.0.38-beta.cue.
3. Open that CUE in your PlayStation emulator. Boot fresh, then load your
   existing in-game memory-card save to continue playing after updating.
4. Avoid emulator save states from other patch versions.

Patched BIN SHA-256:
136f4780d7712dd43104a703bfba6976310cab9f6ac802b82f4d95e804cfb93e

PLAYTESTING
Back up your saves. v38 passed static code, data, patch and disc checks.
No emulator or instruction-emulation testing was performed for this version.
Full campaign playthroughs and original-hardware
compatibility remain unverified. Some names are shortened, and some area
transitions may load more slowly than in the Japanese game.
For bugs, report the version, campaign, location and steps to reproduce;
include a screenshot and, if possible, a save from before the issue.

Game and BIOS files are not included.
