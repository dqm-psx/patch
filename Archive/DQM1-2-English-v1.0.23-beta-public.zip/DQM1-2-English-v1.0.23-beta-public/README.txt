DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.23 beta - public playtest package

English text and title artwork for Terry's, Cobi's and Tara's adventures,
with menu fixes and expanded HP/MP displays.

REQUIRED GAME
An unmodified Japanese PlayStation BIN, serial SLPM-87050.
Size: 260,975,568 bytes
Source SHA-256:
a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29

INSTALL
1. Extract this ZIP. Apply the included .bps to the original Japanese BIN
   using a BPS patcher, such as https://www.marcrobledo.com/RomPatcher.js/
   Do not apply it to an already translated image. Keep checksum validation on.
2. Name the patched output DQM1-2-English-v1.0.23-beta.bin and put it beside
   the included DQM1-2-English-v1.0.23-beta.cue.
3. Open that CUE in your PlayStation emulator. Start the game fresh or load
   an in-game memory-card save; avoid save states from another patch version.

Patched BIN SHA-256:
d24e4309ee3b44d05c42d0d519d2796d630be49f77f0e49eb683195a51a2c006

PLAYTESTING
Back up your saves. Complete campaign playthroughs and original-hardware
compatibility have not been verified. Some names are shortened to fit menus.
For bug reports, include the patch version, campaign, location, steps and
a screenshot; a save from before the issue is helpful.

Unofficial fan translation. The original game and BIOS are not included.
