DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.62 - public release
Package: DQM1-2-English-v1.0.62-public.zip

Unofficial fan English translation of
ドラゴンクエストモンスターズ1・2 星降りの勇者と牧場の仲間たち
(Dragon Quest Monsters 1 & 2: The Starry Night Hero and Friends at the Ranch).

English text and title artwork for Terry's, Cobi's and Tara's adventures.

PUBLIC RELEASE HIGHLIGHTS
v62 (corrected audio ownership build):
- Includes the breeding/shrine fixes and an audio memory leak fix for the
  reported ClockBird crash when returning to GreatLog.
- Includes the earlier gate and battle transition fixes.
Thanks to nextlvlroy and BalK for the bug reports and save files!
Thanks also to nextlvlroy for helping reproduce and test the ClockBird crash.

This v62 package uses the corrected audio ownership build, which differs
from the earlier v62 build.

v61:
- Alternative translation options, including Game Boy and Game Boy
  delocalization wording, are available in Discord. Translation work
  remains in progress.

v60:

- Fixed bug with NPC monster breeding offer. Thanks gollum_007 for the bug report!

v59:

- Fixes the reported crash when Baramos learns HellSpark with a full
  skill list. Thanks to Lori for reporting and confirming the fix!
- Corrects description-window initialization and placement in the
  skill-forgetting menu.
- Based on public v57 with the tested skill-learning correction.

v57:

- Ice world map fix; thanks Wingforth for the bug report!

v56:

- Not released, still working on font improvements

v55:

- Improved translations for battle messages

v54:

- Corrected malformed battle messages

v53:

- Translates the appraisal certificate heading and four printed labels.
- Corrects the certificate's character spacing and centered temperament
  line so English appraisal text fits within its border.
- Retains v52's dialogue formatter and all prior translation content
  and gameplay fixes.

v52:

- Fixes rapid dialogue scrolling after the nut pie scene and in Cobi's
  ship conversation. The shared formatter now preserves the spacing
  of already wrapped dialogue. Thanks to _Zev for the report!
- Retains all v51 translation content, fonts and prior fixes.
- The project owner playtested v52 and reported that it seems to work.

v51:

- Fixes the reproduced King dialogue freeze after the Starry Night final.
  The valley scene now advances with its graphics intact.
- Fixes a verified battle-memory overwrite during attack loading.
- Includes v49's combat skill panel correction and all earlier fixes.
  Thanks to Schnaki and _Zev for the crash reports!

v49:

- Combat skill descriptions now fit in a full-width panel below the skill
  choices. MP cost remains on its own row. All three combat menu entry
  paths are corrected; v48 translation, fonts and gameplay fixes remain.

v48:

- Selling part of an item stack now keeps the remaining stack in its
  original inventory position.
- Beavern's default nickname is now Biino. Thanks to Wingforth for the
  suggestion! Names already stored in your save, including names you
  chose, are unchanged.
- Includes restored monster table conversations and special dungeon
  floors in Terry's adventure. See below for details and instructions.

v46: The hidden movement mode works with the hero name Sanic (capital S).
Press and hold Square, keeping it held while changing areas to
activate the mode. Existing saves using the original みんさん
trigger still work.

v45: Clearer item-description headers. Using or discarding one copy keeps
the remaining stack in place, and rejected battle items return the
cursor to the correct row. Retains v43's fonts and dialogue spacing.

v38: Fixed the Master Teto breeding crash and NPC breeding names
overwriting monster data. Thanks to Schnaki for reporting the bug!

v36: Fixed DQM2 gate room text glitches and improved key names.

v34: Fixed the original Japanese game's Truth gate / Digster progression
bug, along with intermittent portal-entry crashes in the
translation patch.

v30: Improved inventory, status bars and dialogue; fixed the
Arena/School transition bug.

v23: English text and title artwork, menu fixes and expanded HP/MP displays.

RESTORED CONTENT IN TERRY'S ADVENTURE

Monster table conversations

The Game Boy original includes a small Easter egg that lets you chat
with your monsters at a table in the Arena. The Japanese PlayStation
release retained 112 conversations, but the table interaction was
unavailable. This patch makes those conversations accessible, with
reconstructed seating and personality matching.

At the arena dining room's right table, walk onto the east stool with
one to three living, visible party monsters.

- Up, Left and Down select the north, west and south monster.
- Confirm/Talk starts a conversation.
- Cancel or Right stands up.

Leave the stool before sitting again, and revive fallen party members
before taking a seat.

Special dungeon floors

The Game Boy original's special dungeon floors return: treasure/Mimic
rooms, Lost Forest, the traveling colosseum, mazes and sliding floors.

These restorations combine unused PS1 maps and other retained assets
with behavior adapted from the Game Boy original. Some mechanics and
encounter rates are reconstruction choices.

Travel Bookmark cannot be used inside the traveling colosseum.
Leave through its north door.

REQUIRED GAME

Unmodified Japanese PlayStation BIN, serial SLPM-87050.
Size: 260,975,568 bytes

Source SHA-256:
a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29

INSTALL

1. Extract this package. Apply its .bps file to the original
   Japanese BIN using a BPS patcher, such as:
   https://www.marcrobledo.com/RomPatcher.js/
   Do not patch an already translated image. Keep checksum validation on.

2. Name the output DQM1-2-English-v1.0.62.bin and place it beside the
   included DQM1-2-English-v1.0.62.cue.

3. Open that CUE in your PlayStation emulator. Boot fresh, then load your
   existing in-game memory-card save to continue playing after updating.

4. Avoid emulator save states from other patch versions, which can
   restore old game code.

Patched BIN SHA-256:
1cfa244f98b22f42cc57534e124383f7e478391b22f297a1ff885f6dc4543aa9 (v62)

BPS SHA-256:
df926aa3dc7e03c14e88c0868cc162f34b9c63b9546b62067c739918da319843

PLAYTESTING

Back up your saves.

Full campaign playthroughs and original-hardware compatibility remain
unverified. Some names are shortened, and some area transitions may load
more slowly than in the Japanese game.

For bugs, report the patch version, campaign, location and steps to
reproduce the issue. If possible, include a screenshot and a save from
before the issue occurred.

Game and BIOS files are not included. Earlier public packages are retained.

https://discord.gg/Y5vrQ5ww9
https://www.romhacking.net/translations/7734/
