DRAGON QUEST MONSTERS 1 & 2 - ENGLISH TRANSLATION
v1.0.52 beta - public playtest
Latest package: DQM1-2-English-v1.0.52-beta-public.zip

Unofficial fan English translation of
ドラゴンクエストモンスターズ1・2 星降りの勇者と牧場の仲間たち
(Dragon Quest Monsters 1 & 2: The Starry Night Hero and Friends at the Ranch).

English text and title artwork for Terry's, Cobi's and Tara's adventures.


PUBLIC RELEASE HIGHLIGHTS

v52:
- Fixes rapid dialogue scrolling after the nut pie scene and in Cobi's
  ship conversation. The shared formatter now preserves the spacing
  of already wrapped dialogue. Thanks to _Zev for the report!
- Retains all v51 translation content, fonts and prior fixes.

v51:
- Fixes the reproduced King dialogue freeze after the Starry Night final.
  The valley scene now advances with its graphics intact.
- Fixes a verified battle-memory overwrite during attack loading.
- Includes v49's combat skill panel correction and all earlier fixes.
  Thanks to Schnaki and _Zev for the crash reports!

v49:
- Combat skill descriptions now fit in a full-width panel below the skill
  choices. MP cost remains on its own row. All three combat menu entry
  paths are corrected; v48 translation, fonts and gameplay fixes remain.

v48:
- Selling part of an item stack now keeps the remaining stack in its
  original inventory position.
- Beavern's default nickname is now Biino. Thanks to Wingforth for the
  suggestion! Names already stored in your save, including names you
  chose, are unchanged.
- Includes restored monster table conversations and special dungeon
  floors in Terry's adventure. See below for details and instructions.

v46: The hidden movement mode works with the hero name Sanic (capital S).
     Press and hold Square, keeping it held while changing areas to
     activate the mode. Existing saves using the original みんさん
     trigger still work.

v45: Clearer item-description headers. Using or discarding one copy keeps
     the remaining stack in place, and rejected battle items return the
     cursor to the correct row. Retains v43's fonts and dialogue spacing.

v38: Fixed the Master Teto breeding crash and NPC breeding names
     overwriting monster data. Thanks to Schnaki for reporting the bug!

v36: Fixed DQM2 gate room text glitches and improved key names.

v34: Fixed the original Japanese game's Truth gate / Digster progression
     bug, along with intermittent portal-entry crashes in the
     translation patch.

v30: Improved inventory, status bars and dialogue; fixed the
     Arena/School transition bug.

v23: English text and title artwork, menu fixes and expanded HP/MP displays.


RESTORED CONTENT IN TERRY'S ADVENTURE

Monster table conversations

The Game Boy original includes a small Easter egg that lets you chat
with your monsters at a table in the Arena. The Japanese PlayStation
release retained 112 conversations, but the table interaction was
unavailable. This patch makes those conversations accessible, with
reconstructed seating and personality matching.

At the arena dining room's right table, walk onto the east stool with
one to three living, visible party monsters.

- Up, Left and Down select the north, west and south monster.
- Confirm/Talk starts a conversation.
- Cancel or Right stands up.

Leave the stool before sitting again, and revive fallen party members
before taking a seat.

Special dungeon floors

The Game Boy original's special dungeon floors return: treasure/Mimic
rooms, Lost Forest, the traveling colosseum, mazes and sliding floors.

These restorations combine unused PS1 maps and other retained assets
with behavior adapted from the Game Boy original. Some mechanics and
encounter rates are reconstruction choices.

Travel Bookmark cannot be used inside the traveling colosseum.
Leave through its north door.


REQUIRED GAME

Unmodified Japanese PlayStation BIN, serial SLPM-87050.
Size: 260,975,568 bytes

Source SHA-256:
a1217657786430ac1c3ad71f16cdadb65d47b0df9a7e30278900651c1f1eec29


INSTALL

1. Extract the latest package. Apply its .bps file to the original
   Japanese BIN using a BPS patcher, such as:
   https://www.marcrobledo.com/RomPatcher.js/
   Do not patch an already translated image. Keep checksum validation on.

2. Name the output DQM1-2-English-v1.0.52-beta.bin and place it beside the
   included DQM1-2-English-v1.0.52-beta.cue.

3. Open that CUE in your PlayStation emulator. Boot fresh, then load your
   existing in-game memory-card save to continue playing after updating.

4. Avoid emulator save states from other patch versions, which can
   restore old game code.

Patched BIN SHA-256:
5e21d46f688ffc35eb4d810803e6f3e7fa5c9c8587d897c7aa3a2e40dae4211b


PLAYTESTING

Back up your saves. v52 passed 21 focused static checks, a complete-disc
comparison, and exact BPS roundtrip verification. Only one formatter
instruction and required checksums differ from v51.

Earlier v51 passed 40 focused static checks and complete-disc checks.
Its targeted runtime results are preserved below.

A targeted DuckStation test used cheats to win the actual Starry Night
final, then advanced the normal valley dialogue. The King page and
background graphics were checked visually, and controls responded after
the dialogue. This does not verify the entire ending or save sequence.
Separate native tests verify the battle-memory correction; the exact
recorded battle setups were not replayed.

Full campaign playthroughs and original-hardware compatibility remain
unverified. Some names are shortened, and some area transitions may load
more slowly than in the Japanese game.

For bugs, report the patch version, campaign, location and steps to
reproduce the issue. If possible, include a screenshot and a save from
before the issue occurred.

Game and BIOS files are not included. Earlier public packages are retained.
